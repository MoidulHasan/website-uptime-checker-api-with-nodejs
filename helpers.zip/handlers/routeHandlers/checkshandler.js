/**
 * Title: Checks
 * Descriptions: Handler to hadle user defined checks
 * Author: Moidul Hasan Khan
 * Date: 28 February 2022
 */

// Dependencies
const { tokenHandler } = require('./tokenHandler');
const { data } = require('../lib/data');
// Module Scafolding
const handler = {};

handler.checkHandler = (requestPropoerty, callback) => {
    const acceptMethods = ['post', 'get', 'put', 'delete'];
    if (acceptMethods.indexOf(requestPropoerty.method) > -1) {
        handler._checks[requestPropoerty.method](requestPropoerty, callback);
    } else {
        callback(405, {
            error: "You have error on your request"
        });
    }
};


handler._checks = {};

handler._checks.post = (requestProperty, callback) => {
    // verify token
    const token = typeof(requestProperty.headerObj.token) === 'string' ? requestProperty.headerObj.token : false;


    tokenHandler._checks.verify()
};

handler._checks.get = (requestProperty, callback) => {
    callback(200, requestProperty);
};

handler._checks.put = (requestProperty, callback) => {
    callback(200, requestProperty);
};

handler._checks.delete = (requestProperty, callback) => {
    callback(200, requestProperty);
};



module.exports = handler;